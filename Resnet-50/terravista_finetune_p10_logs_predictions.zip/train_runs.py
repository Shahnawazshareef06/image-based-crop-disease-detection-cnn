"""TerraVista final runner (frozen-head or full fine-tuning), shared by Members 1, 2 and 5.

Training mode comes from the config file (`training_mode`):
    "frozen_head_only": backbone frozen AND network kept in eval() (BatchNorm statistics fixed);
                        only the new final linear layer is trained.
    "finetune":         all layers trainable.

One (arch, fraction, seed) run = one folder under  <runs-dir>/<arch>/frac<P>_seed<S>/
(default runs-dir: ./runs_<training_mode>) :
    train.log            full log of the run
    history.csv          per-epoch train/val metrics
    best_model.pt        MODEL-ONLY checkpoint of the best-validation epoch
    val_predictions.csv  per-image validation predictions of that same epoch
    run_summary.json     metrics, params, config hash, environment

Examples
    python train_runs.py --config terravista_frozen_config.json --color-dir <PlantVillage/color> \
        --fractions 0.01 0.05 0.1 0.25 0.5 1.0      # everything (checkpoints for 100% only)
    python train_runs.py --config terravista_frozen_config.json --summarize-only
A fraction of 1.0 uses the full training set in original order, so Member 5 can reuse
Member 1's 100% runs exactly (same code path, config and seeds).
"""
from __future__ import annotations

from terravista_bootstrap import apply_kaggle_triton_guard
apply_kaggle_triton_guard()  # must run before importing torch

import argparse
import csv
import hashlib
import json
import logging
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, f1_score
from torch import nn
from torch.utils.data import DataLoader, Subset
from torchvision import models

from augmentation_pipeline import AUGMENTATION_RECIPES, augment_batch_gpu, get_augmentation_recipe, zero_probability_config
from terravista_dataset import make_plantvillage_datasets
from terravista_resnet50_settings import (
    seed_everything, seed_worker, make_data_generator, NUM_WORKERS, PREFETCH_FACTOR,
    PIN_MEMORY, autocast_context, make_grad_scaler, resolve_device, environment_report,
)

SCRIPT_VERSION = "2"
BASE = Path(__file__).resolve().parent
ARCHS = ("resnet50", "mobilenet_v3_large", "mobilenet_v3_small")


def sha256_file(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build_model(arch: str, num_classes: int, device, frozen: bool = False):
    """ImageNet-pretrained model with a new final linear layer. Returns (model, head_module)."""
    if arch == "resnet50":
        m = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
        m.fc = nn.Linear(m.fc.in_features, num_classes)
        head = m.fc
    elif arch == "mobilenet_v3_large":
        m = models.mobilenet_v3_large(weights=models.MobileNet_V3_Large_Weights.DEFAULT)
        m.classifier[-1] = nn.Linear(m.classifier[-1].in_features, num_classes)
        head = m.classifier[-1]
    elif arch == "mobilenet_v3_small":
        m = models.mobilenet_v3_small(weights=models.MobileNet_V3_Small_Weights.DEFAULT)
        m.classifier[-1] = nn.Linear(m.classifier[-1].in_features, num_classes)
        head = m.classifier[-1]
    else:
        raise ValueError(f"arch must be one of {ARCHS}")
    for p in m.parameters():
        p.requires_grad = True
    if frozen:  # train only the new final layer
        head_ids = {id(p) for p in head.parameters()}
        for p in m.parameters():
            p.requires_grad = id(p) in head_ids
    return m.to(device), head


def make_optimizer(model, head, cfg, frozen=False):
    if frozen:
        return torch.optim.AdamW(list(head.parameters()), lr=cfg["head_lr"], weight_decay=cfg["weight_decay"])
    head_ids = {id(p) for p in head.parameters()}
    backbone = [p for p in model.parameters() if id(p) not in head_ids]
    return torch.optim.AdamW(
        [{"params": backbone, "lr": cfg["backbone_lr"]}, {"params": list(head.parameters()), "lr": cfg["head_lr"]}],
        weight_decay=cfg["weight_decay"],
    )


def stratified_indices(labels: np.ndarray, fraction: float, seed: int) -> np.ndarray:
    """Per-class subset (>=1 per class); nested across fractions for a given seed."""
    rng = np.random.default_rng(int(seed))
    chosen = []
    for c in range(int(labels.max()) + 1):
        idx = np.flatnonzero(labels == c)
        perm = idx[rng.permutation(len(idx))]
        chosen.append(perm[:min(len(idx), max(1, int(round(fraction * len(idx)))))])
    return np.sort(np.concatenate(chosen))


def make_logger(log_path: Path, name: str) -> logging.Logger:
    lg = logging.getLogger(name)
    lg.setLevel(logging.INFO)
    lg.handlers.clear()
    fmt = logging.Formatter("%(asctime)s | %(message)s", "%Y-%m-%d %H:%M:%S")
    for h in (logging.FileHandler(log_path, mode="w", encoding="utf-8"), logging.StreamHandler(sys.stdout)):
        h.setFormatter(fmt); lg.addHandler(h)
    lg.propagate = False
    return lg


def train_one_epoch(model, loader, optimizer, scaler, criterion, recipe, device, frozen=False):
    model.eval() if frozen else model.train()  # frozen: keep BatchNorm statistics fixed
    tot_loss, correct, n = 0.0, 0, 0
    for batch in loader:
        images_u8, labels_cpu = batch[0], batch[1]
        alpha = batch[2] if len(batch) == 3 else None
        if recipe["p_background"] > 0 and alpha is None:
            raise ValueError("p_background > 0 but the dataset returned no alpha mask.")
        images = augment_batch_gpu(images_u8, recipe, device=device, background_alpha_uint8=alpha)
        labels = labels_cpu.to(device=device, dtype=torch.long, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with autocast_context(device):
            logits = model(images)
            loss = criterion(logits, labels)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        bs = labels.size(0)
        tot_loss += float(loss.detach()) * bs
        correct += int((logits.detach().argmax(1) == labels).sum())
        n += bs
    return {"train_loss": tot_loss / n, "train_accuracy": correct / n}


@torch.inference_mode()
def predict(model, loader, criterion, device, num_classes):
    model.eval()
    no_aug = zero_probability_config()
    ys, ps, cs = [], [], []
    tot_loss, n = 0.0, 0
    for batch in loader:
        images = augment_batch_gpu(batch[0], no_aug, device=device)
        labels = batch[1].to(device=device, dtype=torch.long, non_blocking=True)
        with autocast_context(device):
            logits = model(images)
            loss = criterion(logits, labels)
        conf, pred = logits.float().softmax(1).max(1)
        tot_loss += float(loss) * labels.size(0); n += labels.size(0)
        ys.append(labels.cpu().numpy()); ps.append(pred.cpu().numpy()); cs.append(conf.cpu().numpy())
    y, p, c = np.concatenate(ys), np.concatenate(ps), np.concatenate(cs)
    labs = list(range(num_classes))
    m = {"val_loss": tot_loss / n, "val_accuracy": float(accuracy_score(y, p)),
         "val_macro_f1": float(f1_score(y, p, labels=labs, average="macro", zero_division=0)),
         "val_weighted_f1": float(f1_score(y, p, labels=labs, average="weighted", zero_division=0))}
    return m, y, p, c


def run_one(arch, fraction, seed, cfg, cfg_sha, train_ds, val_ds, val_paths, train_labels,
            class_to_idx, runs_dir, device, save_checkpoint):
    pct = f"{fraction * 100:g}"
    run_dir = Path(runs_dir) / arch / f"frac{pct}_seed{seed}"
    summary_file = run_dir / "run_summary.json"
    if summary_file.is_file():
        print(f"Skipping finished run: {arch} frac={pct}% seed={seed}")
        return json.loads(summary_file.read_text(encoding="utf-8"))
    run_dir.mkdir(parents=True, exist_ok=True)
    log = make_logger(run_dir / "train.log", f"{arch}_{pct}_{seed}")

    seed_everything(seed)
    recipe = get_augmentation_recipe(cfg["recipe"])
    K = cfg["num_classes"]
    if fraction >= 1.0:
        train_data, n_train = train_ds, len(train_ds)  # identical to the full-data run
    else:
        idx = stratified_indices(train_labels, fraction, seed)
        train_data, n_train = Subset(train_ds, idx.tolist()), len(idx)
    common = dict(num_workers=NUM_WORKERS, pin_memory=PIN_MEMORY, worker_init_fn=seed_worker)
    if NUM_WORKERS > 0:
        common.update(persistent_workers=True, prefetch_factor=PREFETCH_FACTOR)
    train_loader = DataLoader(train_data, batch_size=cfg["train_batch_size"], shuffle=True,
                              generator=make_data_generator(seed), **common)
    val_loader = DataLoader(val_ds, batch_size=cfg["val_batch_size"], shuffle=False, **common)

    frozen = cfg.get("training_mode", "finetune") == "frozen_head_only"
    model, head = build_model(arch, K, device, frozen=frozen)
    optimizer = make_optimizer(model, head, cfg, frozen=frozen)
    criterion, scaler = nn.CrossEntropyLoss(), make_grad_scaler(device)
    n_params = sum(p.numel() for p in model.parameters())
    n_trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    if frozen:
        assert all(id(p) in {id(q) for q in head.parameters()} for p in model.parameters() if p.requires_grad)
    env = environment_report()
    log.info(f"RUN arch={arch} fraction={fraction} seed={seed} n_train={n_train} n_val={len(val_ds)} "
             f"recipe={cfg['recipe']} epochs={cfg['epochs']} mode={cfg.get('training_mode', 'finetune')} "
             f"params={n_params:,} trainable={n_trainable:,}")
    log.info(f"config={cfg['config_name']} config_sha256={cfg_sha}")
    log.info(f"environment={json.dumps(env)}")

    history, best, best_state, best_pred = [], None, None, None
    t_start = time.time()
    for epoch in range(1, cfg["epochs"] + 1):
        t0 = time.time()
        tr = train_one_epoch(model, train_loader, optimizer, scaler, criterion, recipe, device, frozen=frozen)
        va, y, p, c = predict(model, val_loader, criterion, device, K)
        row = {"arch": arch, "fraction": fraction, "seed": seed, "epoch": epoch,
               "epoch_seconds": round(time.time() - t0, 1), **tr, **va}
        history.append(row)
        log.info(f"epoch {epoch}/{cfg['epochs']} | train loss={tr['train_loss']:.4f} acc={tr['train_accuracy']:.4f} | "
                 f"val loss={va['val_loss']:.4f} acc={va['val_accuracy']:.4f} macro-F1={va['val_macro_f1']:.6f} | "
                 f"{row['epoch_seconds']}s")
        if best is None or va["val_macro_f1"] > best["val_macro_f1"]:
            best = dict(row)
            best_pred = (y.copy(), p.copy(), c.copy())
            if save_checkpoint:
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    train_seconds = time.time() - t_start

    idx_to_class = {v: k for k, v in class_to_idx.items()}
    y, p, c = best_pred
    assert len(y) == len(val_paths)
    pd.DataFrame({"path": val_paths, "y_true": y, "y_pred": p, "confidence": c,
                  "true_class": [idx_to_class[i] for i in y], "pred_class": [idx_to_class[i] for i in p]}
                 ).to_csv(run_dir / "val_predictions.csv", index=False)
    with (run_dir / "history.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(history[0])); w.writeheader(); w.writerows(history)
    ckpt_mb = None
    if save_checkpoint:
        torch.save({"model_state_dict": best_state, "arch": arch, "num_classes": K, "seed": seed,
                    "fraction": fraction, "best_epoch": best["epoch"], "class_to_idx": dict(class_to_idx),
                    "config_name": cfg["config_name"], "config_sha256": cfg_sha,
                    "imagenet_mean": [0.485, 0.456, 0.406], "imagenet_std": [0.229, 0.224, 0.225],
                    "input": "RGB uint8 NHWC 224x224 resized with PIL bilinear, then ImageNet-normalized"},
                   run_dir / "best_model.pt")
        ckpt_mb = round((run_dir / "best_model.pt").stat().st_size / 1e6, 2)
    summary = {"arch": arch, "fraction": fraction, "seed": seed, "n_train": n_train,
               "n_val": len(val_ds), "epochs": cfg["epochs"], "recipe": cfg["recipe"],
               "best_epoch": best["epoch"], "best_validation_macro_f1": best["val_macro_f1"],
               "best_validation_accuracy": best["val_accuracy"], "n_params": n_params,
               "n_trainable_params": n_trainable, "training_mode": cfg.get("training_mode", "finetune"),
               "checkpoint_mb": ckpt_mb, "train_seconds": round(train_seconds, 1),
               "config_sha256": cfg_sha, "environment": env}
    summary_file.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    log.info(f"DONE best_epoch={best['epoch']} best_val_macro_f1={best['val_macro_f1']:.6f} "
             f"train_seconds={train_seconds:.0f} checkpoint_mb={ckpt_mb}")
    for h in list(log.handlers):
        h.close(); log.removeHandler(h)
    del model, optimizer
    torch.cuda.empty_cache()
    return summary


def summarize(runs_dir, arch, cfg):
    files = sorted((Path(runs_dir) / arch).glob("frac*_seed*/run_summary.json"))
    if not files:
        print(f"No finished runs found under {Path(runs_dir) / arch}"); return
    df = pd.DataFrame([json.loads(f.read_text(encoding="utf-8")) for f in files])
    g = df.groupby("fraction")
    t = g.agg(n_train=("n_train", "first"), seeds=("seed", "count"),
              mean_val_macro_f1=("best_validation_macro_f1", "mean"),
              sd_val_macro_f1=("best_validation_macro_f1", lambda s: s.std(ddof=1) if len(s) > 1 else float("nan")),
              min_val_macro_f1=("best_validation_macro_f1", "min"),
              max_val_macro_f1=("best_validation_macro_f1", "max"),
              mean_val_accuracy=("best_validation_accuracy", "mean"),
              n_params=("n_params", "first"), mean_train_seconds=("train_seconds", "mean")).reset_index()
    out = Path(runs_dir) / arch
    t.to_csv(out / "summary_by_fraction.csv", index=False)
    df.sort_values(["fraction", "seed"]).to_csv(out / "all_runs.csv", index=False)
    print(t.round(4).to_string(index=False))
    if (t.fraction == 1.0).any():
        full = float(t.loc[t.fraction == 1.0, "mean_val_macro_f1"].iloc[0])
        a, w = cfg["thresholds"]["absolute_macro_f1"], cfg["thresholds"]["within_of_full_data"]
        ok_a = t[t.mean_val_macro_f1 >= a]; ok_w = t[t.mean_val_macro_f1 >= full - w]
        print(f"\nFull-data mean val macro-F1 = {full:.4f}")
        print(f"Smallest tested fraction with mean >= {a}: " +
              (f"{ok_a.fraction.min() * 100:g}%" if len(ok_a) else "none tested"))
        print(f"Smallest tested fraction within {w} of full ({full - w:.4f}): " +
              (f"{ok_w.fraction.min() * 100:g}%" if len(ok_w) else "none tested"))
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.errorbar(t.fraction * 100, t.mean_val_macro_f1, yerr=t.sd_val_macro_f1.fillna(0), marker="o", capsize=4, color="#2a9d8f")
        ax.scatter(df.fraction * 100, df.best_validation_macro_f1, c="k", s=12, zorder=3)
        ax.axhline(a, ls="--", color="#e76f51", label=f"{a}")
        ax.axhline(full - w, ls=":", color="#4c78a8", label=f"full − {w} = {full - w:.3f}")
        ax.set_xscale("log"); ax.set_xticks(t.fraction * 100); ax.set_xticklabels([f"{f * 100:g}%" for f in t.fraction])
        ax.set_xlabel("Training data (log scale)"); ax.set_ylabel("Validation macro-F1")
        ax.set_title(f"{arch}: data-efficiency (mean ± SD over seeds, dots = seeds)"); ax.legend()
        ax.spines[["top", "right"]].set_visible(False)
        fig.tight_layout(); fig.savefig(out / "data_efficiency_curve.png", dpi=150); plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(BASE / "terravista_final_config.json"))
    ap.add_argument("--color-dir")
    ap.add_argument("--arch", default="resnet50", choices=ARCHS)
    ap.add_argument("--fractions", nargs="+", type=float, default=[1.0])
    ap.add_argument("--seeds", nargs="+", type=int, default=None)
    ap.add_argument("--runs-dir", default=None, help="default: ./runs_<training_mode>")
    ap.add_argument("--split-csv", default=str(BASE / "train_val_split.csv"))
    ap.add_argument("--cache-dir", default="./terravista_cache")
    ap.add_argument("--reuse-cache-dir", nargs="*", default=[])
    ap.add_argument("--checkpoints", choices=["full", "all", "none"], default="full",
                    help="full (default): save best_model.pt only for fraction 1.0; all: every run; none: never")
    ap.add_argument("--summarize-only", action="store_true")
    args = ap.parse_args()

    cfg = json.loads(Path(args.config).read_text(encoding="utf-8"))
    cfg_sha = sha256_file(args.config)
    if args.runs_dir is None:
        args.runs_dir = f"./runs_{cfg.get('training_mode', 'finetune')}"
    if args.summarize_only:
        summarize(args.runs_dir, args.arch, cfg); return
    if not args.color_dir:
        ap.error("--color-dir is required unless --summarize-only")
    seeds = args.seeds or cfg["seeds"]
    print(f"train_runs.py version {SCRIPT_VERSION} | config {args.config}")

    device = resolve_device()
    if device.type != "cuda":
        raise RuntimeError("CUDA GPU required for the final runs.")
    class_path = BASE / "class_to_idx.json"
    if sha256_file(class_path) != cfg["class_map_sha256"]:
        raise RuntimeError("class_to_idx.json does not match the config's class_map_sha256.")
    if sha256_file(args.split_csv) != cfg["split_csv_sha256"]:
        raise RuntimeError("Split CSV does not match the config's split_csv_sha256.")
    class_to_idx = json.loads(class_path.read_text(encoding="utf-8"))

    # Drop any non train/val rows before a single path is resolved (test stays untouched).
    sdf = pd.read_csv(args.split_csv)
    sdf["split"] = sdf["split"].astype(str).str.strip().str.lower()
    keep = sdf["split"].isin(["train", "val"])
    split_csv = Path(args.split_csv)
    if not keep.all():
        split_csv = Path(args.runs_dir) / "train_val_only_split.csv"
        split_csv.parent.mkdir(parents=True, exist_ok=True)
        sdf[keep].to_csv(split_csv, index=False)

    need_masks = AUGMENTATION_RECIPES[cfg["recipe"]]["p_background"] > 0
    train_ds, val_ds, train_df, val_df, *_ = make_plantvillage_datasets(
        str(split_csv), args.color_dir, class_to_idx, need_background_masks=need_masks,
        cache_dir=args.cache_dir, reuse_cache_dirs=args.reuse_cache_dir)
    train_labels = train_df["class"].map(class_to_idx).to_numpy()
    val_paths = val_df["path"].tolist()
    assert len(train_labels) == len(train_ds) and len(val_paths) == len(val_ds)
    print(f"Train={len(train_ds):,} | Val={len(val_ds):,} | arch={args.arch} | config={cfg['config_name']} "
          f"sha={cfg_sha[:12]} | test used: NO")

    for seed in seeds:
        for fraction in sorted(args.fractions):
            run_one(args.arch, fraction, seed, cfg, cfg_sha, train_ds, val_ds, val_paths, train_labels,
                    class_to_idx, args.runs_dir, device,
                    save_checkpoint=(args.checkpoints == "all" or (args.checkpoints == "full" and fraction >= 1.0)))
    print()
    summarize(args.runs_dir, args.arch, cfg)


if __name__ == "__main__":
    main()
